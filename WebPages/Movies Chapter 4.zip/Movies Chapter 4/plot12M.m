function plot12M

clf
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

vid = VideoWriter('/Users/mark/Desktop/phase12','MPEG-4');
open(vid)

%%%% get(gcf)
set(gcf,'Position', [25 817 778 528])
subaxis(1,1,1,1,'MT',0.06,'MB',0.06,'MR',-0.01,'ML',0.03,'P',0.04)
hold on
axis([-10 10 -5 5])
xticks([-10 -5 0 5 10])
yticks([-5 0 5])
box on
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')

tmax=2;
nt=200;
t=linspace(-2,2,nt);




x0=6
y0=-3
c10=(2*x0+3*y0)/5
c20=(x0-y0)/5

% y=0
c1=[-9 -6 -3  3 6 9]*2/5;
%c1=[-9 -6 -3   6 9]*2/5;
nj=length(c1);
c2=c1/2;


% x=0
cc1=[-4 -2.8 -3/2  3/2 2.8 4]*3/5;
cc2=-cc1/3;

r1=2; a1=1; a2=1;
r2=-3;  aa1=3; aa2=-2;

for it=1:nt
    
    if it>1 && t(it-1)<0 && t(it)>=0
        I=it;
    end
    
    xs(it)=c10*a1*exp(r1*t(it))+c20*aa1*exp(r2*t(it));
    ys(it)=c10*a2*exp(r1*t(it))+c20*aa2*exp(r2*t(it));
    
    for j=1:nj
        x(it,j)=c1(j)*a1*exp(r1*t(it))+c2(j)*aa1*exp(r2*t(it));
        y(it,j)=c1(j)*a2*exp(r1*t(it))+c2(j)*aa2*exp(r2*t(it));
    end
    
    for j=1:nj
        xx(it,j)=cc1(j)*a1*exp(r1*t(it))+cc2(j)*aa1*exp(r2*t(it));
        yy(it,j)=cc1(j)*a2*exp(r1*t(it))+cc2(j)*aa2*exp(r2*t(it));
    end
    
    x1(it)=a1*exp(r1*t(it));
    y1(it)=a2*exp(r1*t(it));
    
    x2(it)=aa1*exp(r2*t(it));
    y2(it)=aa2*exp(r2*t(it));
    
end

for j=1:nj
    
    plot(x(:,j),y(:,j),'--b','LineWidth',0.8)
    %i=I-1; ii=i+1; arrowhead([x(i,j) x(ii,j)],[y(i,j) y(ii,j)],'b',[arrS arrS],3);
    
    plot(xx(:,j),yy(:,j),'--b','LineWidth',0.8)
    %i=I-8; ii=i+1; arrowhead([xx(i,j) xx(ii,j)],[yy(i,j) yy(ii,j)],'b',[arrS arrS],3);
    
end

arrS=0.8;
plot(x1,y1,'r','LineWidth',1.5)
i=I+5; ii=i+1; arrowhead([x1(i) x1(ii)],[y1(i) y1(ii)],'r',[arrS arrS],3);
plot(x2,y2,'r','LineWidth',1.5)
i=I+5; ii=i+1; arrowhead([x2(i) x2(ii)],[y2(i) y2(ii)],'r',[arrS arrS],3);

plot(-x1,-y1,'r','LineWidth',1.5)
i=I+5; ii=i+1; arrowhead([-x1(i) -x1(ii)],[-y1(i) -y1(ii)],'r',[arrS arrS],3);
plot(-x2,-y2,'r','LineWidth',1.5)
i=I+5; ii=i+1; arrowhead([-x2(i) -x2(ii)],[-y2(i) -y2(ii)],'r',[arrS arrS],3);

grid on

say=['$\mathbf{x}^\prime = \left( \begin{array}{ccc}-1 & 3 \\2 & 0 \end{array} \right)\mathbf{x} \quad\quad \quad $\textbullet \, = Initial Point'];
title(say,'FontSize',16,'FontWeight','bold','Interpreter','Latex')

say=['Holmes, 2020'];
text(8,-5.9,say,'FontSize',10,'FontWeight','bold')


% create solution curves

nt=200;
tmax=2;
tt=linspace(0,tmax,nt);

x0=[-8 -10  6.2  9.2 -5  5];
y0=[5   3   -5  -5  5 6 ];

for j=1:length(x0)
    plot(x0(j),y0(j),'.k','LineWidth',2,'MarkerSize',30)
end

F = getframe(gcf);
writeVideo(vid,F);

dett=a1*aa2-a2*aa1;
for j=1:length(x0)

    c10=(aa2*x0(j)-aa1*y0(j))/dett;
    c20=(-a2*x0(j)+a1*y0(j))/dett;
    ai=8;
    for it=1:nt
        xs(it)=c10*a1*exp(r1*tt(it))+c20*aa1*exp(r2*tt(it));
        ys(it)=c10*a2*exp(r1*tt(it))+c20*aa2*exp(r2*tt(it));
        if abs(xs(it))<6 && abs(ys(it))<3.5
            ai=it;
        end
        if abs(xs(it))<11 && abs(ys(it))<6
            N=it;
        end
    end
    
    plot(xs(1),ys(1),'.b','LineWidth',2,'MarkerSize',30)
    
    F = getframe(gcf);
    for i=1:15
        writeVideo(vid,F);
    end
    
    for i=1:3:N
        plot(xs(1:i),ys(1:i),'-b','LineWidth',1)
        F = getframe(gcf);
        writeVideo(vid,F);
    end
    ai=round(N/4)
    i=ai; ii=i+1; arrowhead([xs(i) xs(ii)],[ys(i) ys(ii)],'b',[arrS 0.7*arrS],3);
    
    for i=1:10
        writeVideo(vid,F);
    end

    %break
    
end









