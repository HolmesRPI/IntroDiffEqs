function plot32M

clf
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

vid = VideoWriter('/Users/mark/Desktop/phase32','MPEG-4');
open(vid)

%%%% get(gcf)
set(gcf,'Position', [25 817 778 528])
subaxis(1,1,1,1,'MT',0.06,'MB',0.06,'MR',-0.01,'ML',0.03,'P',0.04)
hold on
axis([-1 1  -1 1])

xticks([-1 0 1])
yticks([-1 0 1])
box on
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')

nt=400;
t=linspace(-1,7,nt);

% y=0
c1=[-10 -5 1 6 2.6];
nj=length(c1);
c2=c1;

lambda=-1;
mu=3;
for it=1:nt
    
    for j=1:nj
        c=cos(mu*t(it)); s=sin(mu*t(it));
        x(it,j)=(c1(j)*c+c2(j)*s)*exp(lambda*t(it));
        y(it,j)=(-c1(j)*(c+s)+c2(j)*(-s+c))*exp(lambda*t(it));
        if abs(x(it,j))>0.5 && abs(y(it,j))>0.5
            ai(j)=it;
        end
        
        if j==3 && 0.5<x(it,j)<1 && 0.5<y(it,j)<1
            j3=it;
        end
    end
    
end
ai



aaJ=10;
for j=1:nj
    
    plot(x(:,j),y(:,j),'--r','LineWidth',0.8)
    
end
arrS=0.5;
% j=1;
% i=ai(j)+24; ii=i+1; arrowhead([x(i,j) x(ii,j)],[y(i,j) y(ii,j)],'b',[arrS arrS],3);
% i=ai(j)-35; ii=i+1; arrowhead([x(i,j) x(ii,j)],[y(i,j) y(ii,j)],'b',[arrS arrS],3);
%
j=2;
% i=ai(j)+32; ii=i+1; arrowhead([x(i,j) x(ii,j)],[y(i,j) y(ii,j)],'b',[arrS arrS],3);
i=ai(j)-28; ii=i+1; arrowhead([x(i,j) x(ii,j)],[y(i,j) y(ii,j)],'r',[arrS arrS],3);
%
%j=3;
%i=ai(j)-32; ii=i+1; arrowhead([x(i,j) x(ii,j)],[y(i,j) y(ii,j)],'r',[arrS arrS],3);
%i=ai(j)+15; ii=i+1; arrowhead([x(i,j) x(ii,j)],[y(i,j) y(ii,j)],'r',[arrS arrS],3);
%
% j=4;
% i=ai(j)+14; ii=i+1; arrowhead([x(i,j) x(ii,j)],[y(i,j) y(ii,j)],'b',[arrS arrS],3);
% i=ai(j)-30; ii=i+1; arrowhead([x(i,j) x(ii,j)],[y(i,j) y(ii,j)],'b',[arrS arrS],3);
%
% j=5;
% i=ai(j)-32; ii=i+1; arrowhead([x(i,j) x(ii,j)],[y(i,j) y(ii,j)],'b',[arrS arrS],3);
% i=ai(j)+28; ii=i+1; arrowhead([x(i,j) x(ii,j)],[y(i,j) y(ii,j)],'b',[arrS arrS],3);


grid on

say=['$\mathbf{x}^\prime = \left( \begin{array}{ccc}-2 & 1 \\-10 & 0 \end{array} \right)\mathbf{x} \quad\quad \quad $\textbullet \, = Initial Point'];
title(say,'FontSize',16,'FontWeight','bold','Interpreter','Latex')

say=['Holmes, 2020'];
text(0.75,-1.2,say,'FontSize',10,'FontWeight','bold')


%return
% create solution curves
arrS=1;
nt=200;
N=nt;
tmax=5;
tt=linspace(0,tmax,nt);

x0=[0.1 1 -0.31 -200];
y0=[1 -0.7 -1 0];
ai = [10 30 7 5];
for j=1:length(x0)
    plot(x0(j),y0(j),'.k','LineWidth',2,'MarkerSize',30)
end

F = getframe(gcf);
writeVideo(vid,F);

for j=1:length(x0)
    
    if j==length(x0)
        nt=10;
        N=nt;
        tmax=0.1;
        tt=linspace(0,tmax,nt);
    end
    
    c10=x0(j);
    c20=x0(j)+y0(j);
    for it=1:nt
        xs(it)=c10*exp(3*tt(it))+c20*exp(tt(it));
        ys(it)=c10*exp(3*tt(it))-c20*exp(tt(it));
        c=cos(mu*tt(it)); s=sin(mu*tt(it));
        xs(it)=(c10*c+c20*s)*exp(lambda*tt(it));
        ys(it)=(-c10*(c+s)+c20*(-s+c))*exp(lambda*tt(it));
        
    end
    
    plot(xs(1),ys(1),'.b','LineWidth',2,'MarkerSize',30)
    
    F = getframe(gcf);
    for i=1:15
        writeVideo(vid,F);
    end
    
    for i=1:2:N
        plot(xs(1:i),ys(1:i),'-b','LineWidth',1)
        F = getframe(gcf);
        writeVideo(vid,F);
    end
    
    i=ai(j); ii=i+1; arrowhead([xs(i) xs(ii)],[ys(i) ys(ii)],'b',[arrS 0.7*arrS],3);
    
    for i=1:10
        writeVideo(vid,F);
    end
    
    
    %return
    
end









