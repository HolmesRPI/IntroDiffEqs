function plot11M

clf
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

vid = VideoWriter('/Users/mark/Desktop/phase11','MPEG-4');
open(vid)

%%%% get(gcf)
set(gcf,'Position', [25 817 778 528])
subaxis(1,1,1,1,'MT',0.06,'MB',0.06,'MR',-0.01,'ML',0.03,'P',0.04)
hold on
axis([-10 10 -5 5])

xticks([-10 -5 0 5 10])
yticks([-5 0 5])
box on
xlabel('x-axis')
ylabel('y-axis')
set(gca,'FontSize',16,'FontWeight','bold')

nt=2000;
tmax=2;
t=linspace(-3,tmax,nt);

for it=1:nt
    x1(it)=exp(3*t(it));
    y1(it)=x1(it);
    if x1(it)^2+y1(it)^2<30
        a=it;
    end
    
    x2(it)=exp(t(it));
    y2(it)=-x2(it);
    if x2(it)^2+y2(it)^2<30
        aa=it;
    end
end

arrS=0.7;
plot(x1,y1,'r','LineWidth',1.5)
i=a; ii=i+1; arrowhead([x1(i) x1(ii)],[y1(i) y1(ii)],'r',[arrS arrS],3);
plot(x2,y2,'r','LineWidth',1.5)
i=aa; ii=i+1; arrowhead([x2(i) x2(ii)],[y2(i) y2(ii)],'r',[arrS arrS],3);

plot(-x1,-y1,'r','LineWidth',1.5)
i=a; ii=i+1; arrowhead([-x1(i) -x1(ii)],[-y1(i) -y1(ii)],'r',[arrS arrS],3);
plot(-x2,-y2,'r','LineWidth',1.5)
i=aa; ii=i+1; arrowhead([-x2(i) -x2(ii)],[-y2(i) -y2(ii)],'r',[arrS arrS],3);

c1=[-9  -4 -3/2 3/2 4 9];
c2=c1;

cc1=[-7  -3/2 -1/2 1/2 3/2 7];
cc2=-cc1;
nc=length(c1);
for it=1:nt
    for j=1:nc
        
        x(it,j)=c1(j)*exp(3*t(it))+c2(j)*exp(t(it));
        y(it,j)=c1(j)*exp(3*t(it))-c2(j)*exp(t(it));
        %if x(it,j)^2+y(it,j)^2<50
        if abs(x(it,j))<7 && abs(y(it,j))<4
            ai(j)=it;
        end
    end
    
    for j=1:nc
        xx(it,j)=cc1(j)*exp(3*t(it))+cc2(j)*exp(t(it));
        yy(it,j)=cc1(j)*exp(3*t(it))-cc2(j)*exp(t(it));
        %if xx(it,j)^2+yy(it,j)^2<20
        if abs(xx(it,j))<7 && abs(yy(it,j))<4
            aai(j)=it;
        end
    end
end

for j=1:nc
    plot(x(:,j),y(:,j),'--b','LineWidth',0.8)
    plot(xx(:,j),yy(:,j),'--b','LineWidth',0.8)
end

grid on

say=['$\mathbf{x}^\prime = \left( \begin{array}{ccc}2 & 1 \\1 & 2 \end{array} \right)\mathbf{x} \quad\quad \quad $\textbullet \, = Initial Point'];
title(say,'FontSize',16,'FontWeight','bold','Interpreter','Latex')

say=['Holmes, 2020'];
text(8,-5.9,say,'FontSize',10,'FontWeight','bold')

%return
% create solution curves

nt=200;
tmax=2;
tt=linspace(0,tmax,nt);

x0=[-2 -1 0.3 3 0  5];
y0=[1.6 0.3 -1 -2.6 0.3 6 ];

for j=1:length(x0)
    plot(x0(j),y0(j),'.k','LineWidth',2,'MarkerSize',30)
end

F = getframe(gcf);
writeVideo(vid,F);

for j=1:length(x0)
    
    c10=0.5*(x0(j)+y0(j));
    c20=0.5*(x0(j)-y0(j));
    ai=8;
    for it=1:nt
        xs(it)=c10*exp(3*tt(it))+c20*exp(tt(it));
        ys(it)=c10*exp(3*tt(it))-c20*exp(tt(it));
        if abs(xs(it))<6 && abs(ys(it))<3.5
            ai=it;
        end
        if abs(xs(it))<11 && abs(ys(it))<6
            N=it;
        end
    end
    
    plot(xs(1),ys(1),'.b','LineWidth',2,'MarkerSize',30)
    
    F = getframe(gcf);
    for i=1:15
        writeVideo(vid,F);
    end
    
    for i=1:3:N
        plot(xs(1:i),ys(1:i),'-b','LineWidth',1)
        F = getframe(gcf);
        writeVideo(vid,F);   
    end
    
    i=ai; ii=i+1; arrowhead([xs(i) xs(ii)],[ys(i) ys(ii)],'b',[arrS 0.7*arrS],3);
   
    for i=1:10
        writeVideo(vid,F);
    end
    

    %return
    
end












