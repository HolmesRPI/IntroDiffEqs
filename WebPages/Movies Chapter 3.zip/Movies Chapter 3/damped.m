function damped

% videos for SHM:  u''+cu'+k*u=0

k=4;
u0=0; du0=1;

for icase=1:4
    %icase=4;

    if icase==1
        % overdamped c>2*w0
        c=5;
        v = VideoWriter('/Users/mark/Desktop/ExampleA.sec3.10.3','MPEG-4');
    elseif icase==2
        % critcal
        c=2*sqrt(k);
        v = VideoWriter('/Users/mark/Desktop/ExampleB.sec3.10.3','MPEG-4');
    elseif icase==3
        % under
        c=0.5;
        v = VideoWriter('/Users/mark/Desktop/ExampleC.sec3.10.3','MPEG-4');
    elseif icase==4
        % weak
        c=0.01;
        v = VideoWriter('/Users/mark/Desktop/ExampleD.sec3.10.3','MPEG-4');
    end
    w0=sqrt(k);

    open(v)

    clf
    %%%% get(gcf)
    set(gcf,'Position', [6 987 1080 358])

    frames=2;

    tmax=5*pi;
    nt=200;
    t=linspace(0,tmax,nt);

    % number of spring folds
    folds=12;

    L=1.5
    dy=0.1;
    dx=2*dy;
    width=1.5*dx;
    high=width;

    if c>2*w0
        u=over(t,c,w0,u0,du0);
    elseif c<2*w0
        u=under(t,c,w0,u0,du0);
    else
        u=crit(t,c,w0,u0,du0);
    end

    uM=max(abs(u))
    u=u/uM;

    figure(1)
    dx=-dx;
    for it=1:nt
        clf
        axes('Position', [0.06 0.1 0.12 0.85])
        du=(L-u(it)-2*dy)/folds;
        y_spring=[u(it) u(it)+dy];
        x_spring=[0 0];

        for i=1:folds-1
            y_spring=[y_spring u(it)+dy+i*du];
            x_spring=[x_spring dx];
            dx=-dx;
        end
        y_spring=[y_spring L-dy L];
        x_spring=[x_spring 0 0];

        axis([-5*width 5*width -1.4 1.5])
        hold on
        box on
        plot(x_spring,y_spring,'k','LineWidth',2)

        plot(-4.3*width,u(it),'<b','MarkerSize',12,'LineWidth',2)

        dx=abs(dx);

        box_color=[0.6000    0.1428    0.0522];
        h=fill([-3*width 3*width 3*width -3*width],[u(it) u(it) u(it)-high u(it)-high],box_color);
        h.FaceAlpha=0.3;

        ylabel('u(t)','FontSize',17,'FontWeight','bold')
        yticks([-1 0 1])
        yticklabels({'- R','0 ','R'})
        xticks([-100])
        set(gca,'FontSize',16,'FontWeight','bold')
        hold off

        axes('Position', [0.27 0.15 0.72 0.78]);
        hold on

        say=['$u^{\prime\prime}+cu^\prime+ku=0$, \quad $u(0) =\,\,$', num2str(u0),', \quad $u^\prime(0) = \,\,$',num2str(du0),', \quad $k = \,\,$',num2str(k),', \quad $c= \,\,$',num2str(c)];
        title(say,'FontSize',16,'FontWeight','bold','Interpreter','Latex')

        axis([0 tmax -1 1])
        plot(0,u(1),'.b','MarkerSize',40)
        if it>1
            plot(t(1:it),u(1:it),'b','LineWidth',1.5)
        end

        if icase==1
            % overdamped c>2*w0
            say=['Overdamped'];
        elseif icase==2
            % critcal
            say=['Critical'];
        elseif icase==3
            % under
            say=['Under'];
        elseif icase==4
            % weak
            say=['Weak'];
        end
        text(0.5,-0.5,say,'FontSize',20,'FontWeight','bold')

        box on
        grid on
        yticks([-1 0 1])
        yticklabels({'- R','0 ','R'})
        xlabel('t','FontSize',17,'FontWeight','bold')
        ylabel('u(t)','FontSize',17,'FontWeight','bold')
        set(gca,'FontSize',16,'FontWeight','bold')

        say=['Holmes, 2023'];
        text(14,-1.25,say,'FontSize',12,'FontWeight','bold')

        %    return
        %     pause
        F = getframe(gcf);
        for i=1:frames
            writeVideo(v,F);
        end
    end
    close(v);
end

function u=over(t,c,w0,u0,du0)
r1=0.5*(-c+sqrt(c^2-4*w0^2));
r2=0.5*(-c-sqrt(c^2-4*w0^2));
c1=(r2*u0-du0)/(r2-r1);
c2=(-r1*u0+du0)/(r2-r1);
for i=1:length(t)
    u(i)=c1*exp(r1*t(i))+c2*exp(r2*t(i));
end

function u=crit(t,c,w0,u0,du0)
r=-c/2
c1=u0;
c2=du0-r*u0;
for i=1:length(t)
    u(i)=c1*exp(r*t(i))+c2*t(i)*exp(r*t(i));
end

function u=under(t,c,w0,u0,du0)
lam=-c/2;  mu=sqrt(4*w0^2-c^2)/2;
R=sqrt(u0^2+((du0-lam*u0)/mu)^2);
if u0==0
    phi=pi/2;
    if du0<lam*u0
        phi=3*pi/2;
    end
else
    z=(du0-lam*u0)/(mu*u0);
    phi=atan(z);
    if u0<0
        phi=phi+pi;
    elseif du0<lam*u0
        phi=phi+2*pi;
    end
end
for it=1:length(t)
    u(it)=R*exp(lam*t(it))*cos(w0*t(it)-phi);
end




























