function fourier_sine_movie

%%%  make your own Fourier sine series movie

%%%  You need to provide the following info:
%%%     L (line 10), N values (line 12),
%%%     b_n (see lines 17-20), and g (see lines 25-32)

%%% specify length of interval
L = 1;

%%% specify the values for N (numbers are separated by a blank space)
N = [1 3 9 27 81 243 729];

%%% specify the formula for b_n
    function z=b(n)
        %%% example with g(x)=exp(x)
        z=-2*n*pi*(exp(1)*(-1)^n - 1)/(pi^2*n^2 + 1);
        %%% Example 3 sec 7.4
        %z=9*sin(n*pi/3)/(pi^2*n^2);
    end

%%% specify the formula for g(x)
    function z=g(x)
        %%% example with g(x)=exp(x)
        z=exp(x);
        %%% Example 3 sec 7.4
        %         if x<1/3
        %             z=3*x;
        %         else
        %             z=(1-x)*3/2;
        %         end
    end

%%% create an empty movie file named myExample (you can change the name),
%%% this file will appear in the MATLAB documents folder
v = VideoWriter('myExample','MPEG-4');

%%% alternative to line 37: specify the location and name of the file
% v = VideoWriter('/Users/holmes/Desktop/myExample','MPEG-4');

%%%  things you might want to change:
%%%     nx (line 47): this is the number of x points used in the plots
%%%     title and legend (lines 96 and 99)

%%% the code begins
nx=2001;
open(v)
% get(gcf)
set(gcf,'Position', [1 996 692 349])
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

frames=30;
NN=length(N);
x=linspace(0,L,nx);
for ix=1:nx
    G(ix)=g(x(ix));
end
s=zeros(nx,NN);
Ns=[0 N];
for ix=2:nx-1
    for j=1:NN
        if j>1
            s(ix,j)=s(ix,j-1);
        end
        for n=Ns(j)+1:Ns(j+1)
            s(ix,j)=s(ix,j)+b(n)*sin(n*pi*x(ix)/L);
        end
    end
end

MM=max(max(s));
mm=min(min(s));
for j=1:NN
    clf
    axis([0 L 1.1*mm 1.1*MM])
    hold on
    xlabel('x-axis')
    ylabel('g(x)')
    plot(x,G,'b','LineWidth',1.6)
    plot(x,s(:,j),'r','LineWidth',1.6)
    box on
    %yticks([0 0.5 1])
    xticks([0 L/4 L/2 3*L/4 L])
    say=['N = ',num2str(N(j))];
    text(0.55*L,0.975*MM,say,'FontSize',20,'FontWeight','bold')
    set(gca,'FontSize',15,'FontWeight','bold')

    legend({' g(x)',' Sine Series'},'Location','NorthEast','AutoUpdate','off','FontSize',14,'FontWeight','bold')

    % note the LaTeX code between the $ signs
    say=['$Sine \,\, Series \,\, Approximation\!: \,\, g(x) \approx \sum_{n=1}^N b_n \sin(n \pi x/L)$'];
    title(say,'FontSize',14,'FontWeight','bold','Interpreter','Latex')

    % make movie frame
    F = getframe(gcf);
    for i=1:frames
        writeVideo(v,F);
    end
    hold off

end
close(v)

end



