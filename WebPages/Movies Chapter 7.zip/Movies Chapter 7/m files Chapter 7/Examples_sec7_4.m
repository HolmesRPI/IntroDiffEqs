function Examples_sec7_4

%  plots sine series of g(x) for 0 < x < L
%  the formulas for g and b_n are at the end of the file

global icase

% icase=1:  g=exp(x)
% icase=2:  g=cos(3*pi*x)
% icase=3:  g=x^2
icase=3

L=1;

% the code begins
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

if icase==1
    v = VideoWriter('/Users/mark/Desktop/ExampleA.sec7.4','MPEG-4');
elseif icase==2
    v = VideoWriter('/Users/mark/Desktop/ExampleB.sec7.4','MPEG-4');
elseif icase==3
    v = VideoWriter('/Users/mark/Desktop/ExampleC.sec7.4','MPEG-4');
end
open(v)

% get(gcf)
set(gcf,'Position', [1 996 692 349])
subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',0.05,'ML',0.027,'P',0.04)

frames=40;

xx=linspace(0,1,100);
for ix=1:100
    gg(ix)=g(xx(ix));
end

NN=11;
%NN=3
for j=1:NN
    if j==1
        N(1)=1;
    else
        N(j)=2*N(j-1);
    end
end

for j=1:NN
    nx=max(50,10*N(j));
    x=linspace(0,L,nx);
    for ix=1:nx
        sum=0;
        for n=1:N(j)
            sum=sum+b(n)*sin(n*pi*x(ix)/L);
        end
        s(ix,j)=sum;
    end

    clf
    subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',0.05,'ML',0.04,'P',0.04)

    hold on

    if icase==1
        say=['$g(x) = \exp(x) \quad\qquad Sine \,\, Series \,\, Approximation\!: \,\, g(x) \approx \sum_{n=1}^N b_n \sin(n \pi x/L)$'];
        gm=0;  gM=3.3;  top=3.4; delta=0.3; H=-0.5;
        axis([-0.02 1.02 gm gM])
    elseif icase==2
        say=['$g(x) = \cos(3 \pi x) \quad\quad Sine \,\, Series \,\, Approximation\!: \,\, g(x) \approx \sum_{n=1}^N b_n \sin(n \pi x/L)$'];
        gm=-1.25;  gM=1.25;  top=1.35; delta=0.23; H=-1.6;
        axis([-0.02 1.02 gm gM])
        % plot([-0.2 1.2],[0 0],'--k','LineWidth',0.5)
    elseif icase==3
        say=['$g(x) = x^2 \quad\qquad Sine \,\, Series \,\, Approximation\!: \,\, g(x) \approx \sum_{n=1}^N b_n \sin(n \pi x/L)$'];
        gm=-0.1;  gM=1.2;  top=1.25; delta=0.12;  H=-0.28;
        axis([-0.02 1.02 gm gM])
        % plot([-0.2 1.2],[0 0],'--k','LineWidth',0.5)
    end
    title(say,'FontSize',14,'FontWeight','bold','Interpreter','Latex')

    xlabel('x-axis')
    ylabel('g(x)')
    xticks([0 0.25 0.5 0.75 1])

    plot(xx,gg,'b','LineWidth',1)
    plot(x,s(:,j),'-r','LineWidth',1.6)

    legend({' g(x)',' Sine Series'},'Location','North','AutoUpdate','off','FontSize',14,'FontWeight','bold')

    if icase==2 || icase==3
        plot([-0.2 1.2],[0 0],'--k','LineWidth',0.5)
    end

    box on

    say=['N '];
    %text(0.8,0.8,say,'FontSize',20,'FontWeight','bold')
    text(1.05,top,say,'FontSize',20,'FontWeight','bold')

    for jj=1:NN
        say=[num2str(N(jj))];
        if jj==j
            text(1.04,top-delta*j,say,'FontSize',18,'FontWeight','bold', 'Color', 'r')
        else
            text(1.04,top-delta*jj,say,'FontSize',18,'FontWeight','bold')
        end
    end

    % say=['N = ',num2str(N(j))];
    % text(0.42*L,Ny,say,'FontSize',20,'FontWeight','bold')

    say=['Holmes, 2023'];
    text(0.85,H,say,'FontSize',10,'FontWeight','bold')

    %pause
    set(gca,'FontSize',15,'FontWeight','bold')

    % make movie frame
    F = getframe(gcf);

    for i=1:frames
        writeVideo(v,F);
    end

    hold off

end


%  the function
function y=g(x)
global icase
if icase==1
    y=exp(x);
elseif icase==2
    y=cos(3*pi*x);
elseif icase==3
    y=x^2;
end

% the fourier coefficients
function y=b(n)
global icase
if icase==1
    % for y=exp(x)
    y=-2*n*pi*(exp(1)*(-1)^n - 1)/(pi^2*n^2 + 1);
elseif icase==2
    % for y=cos(3*pi*x)
    if n==3
        y=0;
    else
        y=2*n*((-1)^n + 1)/(pi*(n^2 - 9));
    end
elseif icase==3
    % for y=x^2
    y=-2*(n^2*pi^2*(-1)^n - 2*(-1)^n + 2)/(n^3*pi^3);
end
















