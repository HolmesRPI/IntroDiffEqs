function heat_sin_movie

%  plots exact solution of the heat equation
%       D*diff(u,x,x) = diff(u,t)   for xL < x < xR, 0 < t < tmax
%  where
%      u = 0  at x=xL,xR  and  u = sin(2*pi*x)  at t = 0

co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

frames=6;

v = VideoWriter('/Users/mark/Desktop/Example2.sec7.3','MPEG-4');
open(v)

% get(gcf)
set(gcf,'Position', [1 996 692 349])
subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',-0.01,'ML',0.02,'P',0.04)


% set parameters
N=100;
M=80;
tmax=0.3;
xL=0;
xR=2;

% generate the points along the x-axis, x(1)=xL and x(N)=xR
x=linspace(xL,xR,N);

% generate the points along the t-axis, t(1)=0 and t(M)=tmax
%t=linspace(0,tmax,M);
t(1)=0;
dt=linspace(-4,0,M);
for it=2:M
    t(it)=10^dt(it);
end

U=zeros(N,M);
for j=1:M
    for i=1:N
        U(i,j)=sol(x(i),t(j));
    end
end

for j=1:M
    clf
    subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',-0.01,'ML',0.02,'P',0.04)
    axis([0 2 -8 10.2])
    hold on
    
    say=['Solution of Diffusion Equation:  $u(x,0)$ for Example 2'];
    title(say,'FontSize',14,'FontWeight','bold','Interpreter','Latex')
    
    xlabel('x-axis')
    ylabel('Solution')
    
    box on
    
    if j>1
        plot(x,U(:,1),'--r','LineWidth',1)
    end
    plot(x,U(:,j),'-b','LineWidth',1.6)
    
    plot([0 2],[0 0],'--k','LineWidth',0.5)
    if j==1
        legend({' u(x,0)'},'Location','NorthEast','AutoUpdate','off','FontSize',14,'FontWeight','bold')
    else
        legend({' u(x,0)',' u(x,t)'},'Location','NorthEast','AutoUpdate','off','FontSize',14,'FontWeight','bold')
    end
    
    yticks([-8 0 10])
    yticklabels({'-8','0','10'})
    xticks([0 0.5 1 1.5 2])
    
    say=['t = ',num2str(t(j),'%5.4f')];
    text(1.68,5.5,say,'FontSize',20,'FontWeight','bold')
    
    say=['Holmes, 2020'];
    text(1.72,-10.5,say,'FontSize',10,'FontWeight','bold')
    
    set(gca,'FontSize',15,'FontWeight','bold')
    
    % make movie frame
    F = getframe(gcf);
    for i=1:frames
        writeVideo(v,F);
    end
    
    hold off
    
    %pause
    
end

function q=sol(x,t)
q1=3*exp(-pi^2*t/4)*sin(pi*x/2);
q2=-4*exp(-9*pi^2*t/4)*sin(3*pi*x/2);
q3=5*exp(-4*pi^2*t)*sin(2*pi*x);
q=q1+q2+q3;



























