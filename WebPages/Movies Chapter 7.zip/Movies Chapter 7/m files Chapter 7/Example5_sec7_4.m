function Example5_sec7_4

%  plots sine series for step at x=0.25   for 0 < x < L

co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)


v = VideoWriter('/Users/mark/Desktop/Example5.sec7.4','MPEG-4');
open(v)

% get(gcf)
set(gcf,'Position', [1 996 692 349])
subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',0.07,'ML',0.027,'P',0.04)

frames=40;

L=1;

NN=11;
for j=1:NN
    if j==1
        N(1)=2;
    else
        N(j)=2*N(j-1);
    end
end

for j=1:NN
   
    nx=10*N(j);
    x=linspace(0,L,nx);
    for ix=1:nx
        sum=13/8;
        for n=1:N(j)
            cn=2*(cos(n*pi/2)-1)/(n^2*pi^2)-sin(n*pi/2)/(n*pi);
            sum=sum+cn*cos(n*pi*x(ix));
        end
        s(ix,j)=sum;
    end
    
    clf
    subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',0.07,'ML',0.027,'P',0.04)
    axis([0 L 0.9 2.1])
    hold on
    
    say=['$Cosine \,\, Series \,\, Approximation\!: \,\, g(x) \approx a_0/2 + \sum_{n=1}^N a_n \cos(n \pi x/L)$'];
    title(say,'FontSize',14,'FontWeight','bold','Interpreter','Latex')
    
    xlabel('x-axis')
    ylabel('g(x)')
    
    plot([0 0.5],[1 1.5],'b','LineWidth',1)
    plot(x,s(:,j),'-r','LineWidth',1.8)
    
    legend({' g(x)',' Cosine Series'},'Location','NorthWest','AutoUpdate','off','FontSize',14,'FontWeight','bold')
    
    
    plot([0.5 0.5],[1.5 2],'--b','LineWidth',1)
    plot([0.5 1],[2 2],'b','LineWidth',1)
    plot(x,s(:,j),'-r','LineWidth',1.8)
    
    box on
    yticks([1 1.5 2])
    yticklabels({'1','1.5','2'})
    xticks([0 0.25 0.5 0.75 1])
    
    top=2.15; delta=0.11;
        say=['N '];
    %text(0.8,0.8,say,'FontSize',20,'FontWeight','bold')
    text(1.05,top,say,'FontSize',20,'FontWeight','bold')

    for jj=1:NN
        say=[num2str(N(jj))];
        if jj==j
            text(1.04,top-delta*j,say,'FontSize',18,'FontWeight','bold', 'Color', 'r')
        else
            text(1.04,top-delta*jj,say,'FontSize',18,'FontWeight','bold')
        end
    end

    % say=['N = ',num2str(N(j))];
    % text(0.02,1.7,say,'FontSize',20,'FontWeight','bold')
    
    say=['Holmes, 2023'];
    text(0.85,0.72,say,'FontSize',10,'FontWeight','bold')
    
    set(gca,'FontSize',15,'FontWeight','bold')
    
    % make movie frame
    F = getframe(gcf);
    
    for i=1:frames
        writeVideo(v,F);
    end
    
    hold off
    
end








