function Example1_sec7_5

%  plots exact solution of the heat equation
%       diff(u,x,x) = diff(u,t,t)   for xL < x < xR, 0 < t < tmax
%  where
%      u = 0  at x=xL,xR  and  u = 3sin(pi*x)  at t = 0

co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)


v = VideoWriter('/Users/mark/Desktop/Example1.sec7.5','MPEG-4');
open(v)

% get(gcf)
set(gcf,'Position', [1 996 692 349])
subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',-0.01,'ML',0.02,'P',0.04)


% set parameters
N=40;
M=40;
tmax=5;
xL=0;
xR=2;
frames=6;

% generate the points along the x-axis, x(1)=xL and x(N)=xR
x=linspace(xL,xR,N);

% generate the points along the t-axis, t(1)=0 and t(M)=tmax
t=linspace(0,tmax,M);


U=zeros(N,M);
for j=1:M
    for i=1:N
        U(i,j)=3*cos(pi*t(j))*sin(pi*x(i));
    end
end

for j=1:M
    clf
    subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',-0.01,'ML',0.02,'P',0.04)
    axis([0 2 -3 3])
    hold on
    
    %say=['Solution of Wave Equation:  $u(x,t) = \sum_{n=1}^\infty a_n \cos(\pi n t/L) \sin(n \pi x/L)$'];
    say=['Solution of Wave Equation: \quad $u(x,0) = 3\cos(\pi x)$ \quad $u_t(x,0) = 0$'];
    title(say,'FontSize',14,'FontWeight','bold','Interpreter','Latex')
    
    xlabel('x-axis')
    ylabel('Solution')
    
    box on
    
    if j>1
        plot(x,U(:,1),'--r','LineWidth',1)
    end
    plot(x,U(:,j),'-b','LineWidth',1.6)
    
    if j==1
        legend({' u(x,0)'},'Location','NorthEast','AutoUpdate','off','FontSize',14,'FontWeight','bold')
    else
        legend({' u(x,0)',' u(x,t)'},'Location','NorthEast','AutoUpdate','off','FontSize',14,'FontWeight','bold')
    end
    
    yticks([-3 0 3])
    yticklabels({'-3','0','3'})
    xticks([0 0.5 1 1.5 2])
    
    say=['t = ',num2str(t(j),'%4.2f')];
    text(0.85,2.5,say,'FontSize',20,'FontWeight','bold')
    say=['Holmes, 2020'];
    text(1.75,-1.3*3,say,'FontSize',10,'FontWeight','bold')
    set(gca,'FontSize',15,'FontWeight','bold')
    
    % make movie frame
    F = getframe(gcf);
    for i=1:frames
        writeVideo(v,F);
    end

    hold off
    
end






