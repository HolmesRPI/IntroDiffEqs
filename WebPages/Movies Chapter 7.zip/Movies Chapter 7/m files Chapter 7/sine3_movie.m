function sine3_movie

%  plots sine series for step at x=0.25   for 0 < x < L

co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)


v = VideoWriter('/Users/mark/Desktop/sine3','MPEG-4');
open(v)

% get(gcf)
set(gcf,'Position', [1 996 692 349])
subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',-0.01,'ML',0.02,'P',0.04)

frames=30;

L=1;
a=0.25;
nx=4000;
% generate the points along the x-axis, x(1)=xL and x(N)=xR
x=linspace(0,L,nx);

NN=12;

for j=1:NN
    if j==1
        N(1)=1;
    else
        N(j)=2*N(j-1);
    end
    for ix=1:nx
        sum=0;
        for n=1:N(j)
            sum=sum+2*(1-cos(0.25*n*pi))*sin(n*pi*x(ix))/(n*pi);
        end
        s(ix,j)=sum;
    end
end

for j=1:NN
    clf
    subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',-0.01,'ML',0.02,'P',0.04)
    axis([0 L -0.25 1.25])
    hold on
    
    say=['Example 3 (text)  \quad\qquad Sine Series:  $g(x) \approx \sum_{n=1}^N b_n \sin(n \pi x/L)$'];
    title(say,'FontSize',14,'FontWeight','bold','Interpreter','Latex')
    
    xlabel('x-axis')
    ylabel('y-axis')
    
    
    plot([0 a],[1 1],'b','LineWidth',1)
    plot(x,s(:,j),'-r','LineWidth',1.6)
    
    legend({' g(x)',' Sine Series'},'Location','NorthEast','AutoUpdate','off','FontSize',14,'FontWeight','bold')
        
    plot([a a],[0 1],'--b','LineWidth',1)
    plot([a 1],[0 0],'b','LineWidth',1)
    
    box on
    yticks([0 1])
    yticklabels({'0','1'})
    
    say=['N = ',num2str(N(j))];
    text(0.8,0.8,say,'FontSize',20,'FontWeight','bold')
    
    set(gca,'FontSize',15,'FontWeight','bold')
    
    % make movie frame
    F = getframe(gcf);
    
    for i=1:frames
        writeVideo(v,F);
    end
    
    hold off
    
end








