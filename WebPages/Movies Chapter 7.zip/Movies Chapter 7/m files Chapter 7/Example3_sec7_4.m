function Example3_sec7_4

%  plots sine series for x(1-x)   for 0 < x < L

co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)


v = VideoWriter('/Users/mark/Desktop/Example3.sec7.4','MPEG-4');
open(v)

% get(gcf)
set(gcf,'Position', [1 996 692 349])
subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',0.07,'ML',0.03,'P',0.04)

frames=40;
Pi=pi;

L=1;
nx=91;
% generate the points along the x-axis, x(1)=xL and x(N)=xR
x=linspace(0,L,nx);

N = [1 3 9 27 81 243 243*3];
NN=length(N);

for j=1:NN
    for ix=1:nx
        g(ix)=3*x(ix);
        if x(ix)>1/3
            g(ix)=(1-x(ix))*3/2;
        end
        sum=0;
        for n=1:N(j)
            sum=sum+sin(n*pi*x(ix))*(9*sin(Pi*n/3))/(Pi^2*n^2);
        end
        s(ix,j)=sum;
    end
end

for j=1:NN
    clf
    subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',0.07,'ML',0.03,'P',0.04)
    axis([0 1 0 1.07])
    hold on

    say=['$Sine \,\, Series \,\, Approximation\!: \,\, g(x) \approx \sum_{n=1}^N b_n \sin(n \pi x/L)$'];
    title(say,'FontSize',14,'FontWeight','bold','Interpreter','Latex')

    xlabel('x-axis')
    ylabel('g(x)')

    plot(x,g,'b','LineWidth',1.6)
    plot(x,s(:,j),'r','LineWidth',1.6)

    box on


    yticks([0 0.5 1])
    %yticklabels({'-3','0','3'})
    xticks([0 0.25 0.5 0.75 1])

        top=1.12; delta=0.13;
    say=['N '];
    %text(0.8,0.8,say,'FontSize',20,'FontWeight','bold')
    text(1.05,top,say,'FontSize',20,'FontWeight','bold')


    for jj=1:NN
        say=[num2str(N(jj))];
        if jj==j
            text(1.04,top-delta*j,say,'FontSize',18,'FontWeight','bold', 'Color', 'r')
        else
            text(1.04,top-delta*jj,say,'FontSize',18,'FontWeight','bold')
        end
    end

    % say=['N = ',num2str(N(j))];
    % text(0.81,0.7,say,'FontSize',20,'FontWeight','bold')

    say=['Holmes, 2023'];
    text(0.85,-0.15,say,'FontSize',10,'FontWeight','bold')

    set(gca,'FontSize',15,'FontWeight','bold')

    legend({' g(x)',' Sine Series'},'Location','NorthEast','AutoUpdate','off','FontSize',14,'FontWeight','bold')

    % make movie frame
    F = getframe(gcf);

    for i=1:frames
        writeVideo(v,F);
    end

    hold off

end








