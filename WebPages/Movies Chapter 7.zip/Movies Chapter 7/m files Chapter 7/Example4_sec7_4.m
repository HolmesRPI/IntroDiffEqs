function Example4_sec7_4

%  plots sine series for step at x=0.25   for 0 < x < L

co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)


v = VideoWriter('/Users/mark/Desktop/Example4.sec7.4','MPEG-4');
open(v)

% get(gcf)
set(gcf,'Position', [1 996 692 349])
subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',0.07,'ML',0.01,'P',0.04)

frames=40;

L=1;
a=0.25;
nx=4000;
% generate the points along the x-axis, x(1)=xL and x(N)=xR
%x=linspace(0,L,nx);

NN=12;
for j=1:NN
    if j==1
        N(1)=1;
    else
        N(j)=2*N(j-1);
    end
end

for j=1:NN

    nx=10*N(j);
    x=linspace(0,L,nx);
    for ix=1:nx
        sum=0;
        for n=1:N(j)
            sum=sum+2*(1-cos(0.25*n*pi))*sin(n*pi*x(ix))/(n*pi);
        end
        s(ix,j)=sum;
    end

    clf
    subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',0.07,'ML',0.01,'P',0.04)
    axis([-0.02 L -0.25 1.25])
    hold on

    say=['$Sine \,\, Series \,\, Approximation\!: \,\, g(x) \approx \sum_{n=1}^N b_n \sin(n \pi x/L)$'];
    title(say,'FontSize',14,'FontWeight','bold','Interpreter','Latex')

    xlabel('x-axis')
    ylabel('g(x)')

    plot([0 a],[1 1],'b','LineWidth',1.0)
    plot(x,s(:,j),'-r','LineWidth',1.8)
    plot([0 1],[0 0],'--k','LineWidth',0.5)

    legend({' g(x)',' Sine Series'},'Location','NorthEast','AutoUpdate','off','FontSize',14,'FontWeight','bold')

    plot([a a],[0 1],'--b','LineWidth',1)
    plot([a 1],[0 0],'b','LineWidth',1)

    box on
    yticks([0 1])
    yticklabels({'0','1'})
    xticks([0 0.25 0.5 0.75 1])

    say=['N '];
    %text(0.8,0.8,say,'FontSize',20,'FontWeight','bold')
    text(1.05,1.35,say,'FontSize',20,'FontWeight','bold')

    top=1.35; delta=0.13;
    for jj=1:NN
        say=[num2str(N(jj))];
        if jj==j
            text(1.04,top-delta*j,say,'FontSize',18,'FontWeight','bold', 'Color', 'r')
        else
            text(1.04,top-delta*jj,say,'FontSize',18,'FontWeight','bold')
        end
    end
    % say=[num2str(N(j))];
    % text(1.04,top-delta*j,say,'FontSize',18,'FontWeight','bold', 'Color', 'r')

    say=['Holmes, 2023'];
    text(0.85,-0.45,say,'FontSize',10,'FontWeight','bold')

    set(gca,'FontSize',15,'FontWeight','bold')

    % make movie frame
    F = getframe(gcf);

    for i=1:frames
        writeVideo(v,F);
    end

    hold off

end








