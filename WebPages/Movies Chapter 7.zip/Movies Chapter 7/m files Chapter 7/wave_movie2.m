function wave_movie2
%
%  plots sine series solution of the wave equation
%       diff(u,x,x) = diff(u,t,t)   for 0 < x < 1, 0 < t < tmax
%  where
%      u = 0  at x=0,1  and  u = g(x)  and  u_t = 0  at t = 0

a=7/16; b=9/16;
L=b-a;

tmax=6;

% the code begins
co = [0 0 1;
    0 0.5 0;
    1 0 0;
    0 0.75 0.75;
    0.75 0 0.75;
    0.75 0.75 0;
    0.25 0.25 0.25];
set(groot,'defaultAxesColorOrder',co)

v = VideoWriter('/Users/mark/Desktop/wave2','MPEG-4');
open(v)

% get(gcf)
set(gcf,'Position', [1 996 692 349])
subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',-0.01,'ML',0.1,'P',0.04)


% generate the points along the t-axis, t(1)=0 and t(M)=tmax
M=100;
t=linspace(0,tmax,M);
dt=t(2)-t(1);
frames=3;

for j=1:M
    clf
    subaxis(1,1,1,1,'MT',0.08,'MB',0.1,'MR',-0.01,'ML',0.06,'P',0.04)
    axis([0 L -1.1 1.1])
    hold on
    
    % say=['Solution of Wave Equation: \quad $u(x,0) = x^2(1-x)^2$ \quad $u_t(x,0) = 0$'];
    %say=['Solution of Wave Equation: \quad $u(x,0) = x^2(1-x)^2(x-0.25)$ \quad $u_t(x,0) = 0$'];
    say=['Solution of Wave Equation: \quad $u(x,0) = H(h-a)-H(x-b)$ \quad $u_t(x,0) = 0$'];
    title(say,'FontSize',14,'FontWeight','bold','Interpreter','Latex')
    
    xlabel('x-axis')
    ylabel('Solution')
    
    box on
    
    if j==1
        XR=a;  XRR=b;
        XL=b;  XLL=a;
        YR=0.5;
        YL=0.5;
    else
        XR=XR+dt;
        XRR=XR+L;
        if XR<1-0.5*L && XR+L>1
            XRR=2-L+XR;
        elseif XR>1-0.5*L
            XRR=1+XR-L;
            XR=1-XRR;
            YR=-YR;
        elseif
            
        end
        XL=XL-dt;
        XLL=XL-L;
        if XL>0 && XL-L<0
            XLL=L-XL;
        elseif XL<0
            XL=1+(b-a)-dt;
            YL=-YL;
        end
    end
    
    plot([XR XRR],[YR YR],'-b','LineWidth',1.6)
    plot([XR XR],[0 YR],'--b','LineWidth',1.6)
    plot([XRR XRR],[0 YR],'--b','LineWidth',1.6)
    
    plot([XLL XL],[YL YL],'-b','LineWidth',1.6)
    plot([XL XL],[0 YL],'--b','LineWidth',1.6)
    plot([XLL XLL],[0 YL],'--b','LineWidth',1.6)
    
    if j>1
        plot([a b],[1 1],'--b','LineWidth',1)
    end
    
    say=['t = ',num2str(t(j),'%4.1f')];
    text(0.85,0.8,say,'FontSize',20,'FontWeight','bold')
    
    set(gca,'FontSize',15,'FontWeight','bold')
    
    % make movie frame
    F = getframe(gcf);
    for i=1:frames
        writeVideo(v,F);
    end
    
    hold off
    
end















